/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
    This file contains the source code for the MPLAB Harmony application.

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "app.h"

// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback functions.
*/

// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************


/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    DRV_TMR0_Start();
    PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
    PLIB_PORTS_PinDirectionOutputSet(PORTS_ID_0, PORT_CHANNEL_D, PORTS_BIT_POS_8);
    
    PLIB_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
    current = 0;
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    switch(state){
        case NEUTRAL:
            if(((pulses % 150) == 0) && (pulses != 0)){
                state = ZERO;
                rotateToZero();
                PLIB_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
            }
            if((pulses % 10) == 0){
                PLIB_PORTS_PinToggle(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
            }
            break;
        case ZERO:
            if(((pulses % 150) == 0) && (pulses != 0)){
                state = FULL;
                rotateToFull();
                PLIB_PORTS_PinClear(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
            }
            break;
        case FULL:
            if(((pulses % 150) == 0) && (pulses != 0)){
                state = BACK;
                rotateToDegree(137);
                PLIB_PORTS_PinSet(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
            }
            break;
        case BACK:
            if(((pulses % 150) == 0) && (pulses != 0)){
                state = NEUTRAL;
                rotateToNeutral();
                PLIB_PORTS_PinClear(PORTS_ID_0, PORT_CHANNEL_A, PORTS_BIT_POS_3);
            }
            break;
        default:
            //
            break;
    }
}

void rotateToZero(){
    width = ZERO_ROT;
    pulses = 0;
}

void rotateToFull(){
    width = FULL_ROT;
    pulses = 0;
}

void rotateToNeutral(){
    width = NEUT_ROT;
    pulses = 0;
}

void rotateToDegree(int value){
    width = closestStep(value);
    pulses = 0;
}

int closestStep(int value){
    int temp1 = value / 10;
    temp1 = temp1 * 10;
    int temp2 = temp1;
    int retval = 0;
    while((isStep(temp1, &retval) != 1) && (isStep(temp2, &retval) != 1)){
        temp1++;
        temp2--;
    }
    
    return retval;
}

int isStep(int step, int * value){
    int retval = 0;
    switch(step){
        case 0:
            retval = 1;
            *value = 5;
            break;
        case 9:
            retval = 1;
            *value = 6;
            break;
        case 18:
            retval = 1;
            *value = 7;
            break;
        case 27:
            retval = 1;
            *value = 8;
            break;
        case 36:
            retval = 1;
            *value = 9;
            break;
        case 45:
            retval = 1;
            *value = 10;
            break;
        case 54:
            retval = 1;
            *value = 11;
            break;
        case 63:
            retval = 1;
            *value = 12;
            break;
        case 72:
            retval = 1;
            *value = 13;
            break;
        case 81:
            retval = 1;
            *value = 14;
            break;
        case 90:
            retval = 1;
            *value = 15;
            break;
        case 99:
            retval = 1;
            *value = 15;
            break;
        case 108:
            retval = 1;
            *value = 16;
            break;
        case 117:
            retval = 1;
            *value = 17;
            break;
        case 126:
            retval = 1;
            *value = 18;
            break;
        case 135:
            retval = 1;
            *value = 19;
            break;
        case 144:
            retval = 1;
            *value = 20;
            break;
        case 153:
            retval = 1;
            *value = 21;
            break;
        case 162:
            retval = 1;
            *value = 22;
            break;
        case 171:
            retval = 1;
            *value = 23;
            break;
        case 180:
            retval = 1;
            *value = 24;
            break;
        default:
            retval = 0;
            break;
    }
    
    return retval;
}

 

/*******************************************************************************
 End of File
 */
