////////////////////////////////////////////////////////////////////////////////
// Embedded Team 18
// Author(s):   Brad Finagin
// Date:        3/12/18
// Description: This file is contains the Motor Control functions for movement
// as well as location determination
////////////////////////////////////////////////////////////////////////////////
#include "MotorControl.h"

void motorState(){
    switch(mStates.current_State){
        case ROVER_FORWARD:
            setMotor(mStates.current_Speed_M1, 1);
            setMotor(mStates.current_Speed_M2, 0);
            directionForward();
            break;
        case ROVER_BACKWARD:
            setMotor(mStates.current_Speed_M1, 1);
            setMotor(mStates.current_Speed_M2, 0);
            directionBackward();
            break;
        case ROVER_RIGHT:
            setMotor(mStates.current_Speed_M1, 1);
            setMotor(mStates.current_Speed_M2, 0);
                directionRight();
            break;
            case ROVER_LEFT:
            setMotor(mStates.current_Speed_M1, 1);
            setMotor(mStates.current_Speed_M2, 0);
            directionLeft();
            break;
        case ROVER_TURN_TEST:
            setMotor(mStates.current_Speed_M1, 1);
            setMotor(mStates.current_Speed_M2, 0);
            if(mStates.newPoll == 1){
                mStates.newPoll = 0;
                if(mStates.fwd == 1){
                    if(mStates.timeToReachObj ==0){
                        mStates.timeToReachObj = forwardValue12Inches;
                        directionForward();
                    }
                    if((mStates.timeToReachObj - mStates.encoderval1) <= 0 || (mStates.timeToReachObj - mStates.encoderval2) <=0 )
                    {
                        mStates.rght =1;
                        mStates.fwd =0;
                        mStates.timeToReachObj = 0;
                        mStates.current_Speed_M1 = 100;
                        mStates.current_Speed_M2 = 100;
                    }
                    else{
                        mStates.timeToReachObj = mStates.timeToReachObj - ((mStates.encoderval1 + mStates.encoderval2)/2);
                    }
                }
                else if (mStates.rght == 1){
                    if(mStates.timeToReachObj ==0){
                        mStates.timeToReachObj = ninetyDegreeTurn1;
                        directionRight();
                    }
                    if((mStates.timeToReachObj - mStates.encoderval1) <= 0)
                    {
                        mStates.rght =0;
                        mStates.fwd =1;
                        mStates.timeToReachObj = 0;
                        mStates.current_Speed_M1 = 100;
                        mStates.current_Speed_M2 = 100;
                    }
                    else{
                        mStates.timeToReachObj = mStates.timeToReachObj - mStates.encoderval1;
                    }
                }
            }
            break;
        case ROVER_BACKWARDS_TURN_TEST:
            if(mStates.newPoll == 1){
                mStates.newPoll = 0;
                if(mStates.fwd == 1){
                    if(mStates.timeToReachObj ==0){
                        mStates.timeToReachObj = forwardValue12Inches;
                        directionBackward();
                    }
                    if((mStates.timeToReachObj - mStates.encoderval1) <= 0 || (mStates.timeToReachObj - mStates.encoderval2) <=0 )
                    {
                        mStates.rght=1;
                        mStates.fwd =0;
                        mStates.timeToReachObj = 0;
                        mStates.current_Speed_M1 = 100;
                        mStates.current_Speed_M2 = 100;
                    }
                    else{
                        mStates.timeToReachObj = mStates.timeToReachObj - ((mStates.encoderval1 + mStates.encoderval2)/2);
                    }
                }
                else if (mStates.rght == 1){
                    if(mStates.timeToReachObj ==0){
                        mStates.timeToReachObj = ninetyDegreeTurn1;
                        directionLeft();
                    }
                    if((mStates.timeToReachObj - mStates.encoderval1) <= 0)
                    {
                        mStates.rght =0;
                        mStates.fwd =1;
                        mStates.timeToReachObj = 0;
                        mStates.current_Speed_M1 = 100;
                        mStates.current_Speed_M2 = 100;
                    }
                    else{
                        mStates.timeToReachObj = mStates.timeToReachObj - mStates.encoderval1;
                    }
                }
            }
            break;
        case ROVER_LENGTH_FINDING_TEST:
            setMotor(mStates.current_Speed_M1,1);
            setMotor(mStates.current_Speed_M2,0);
            directionForward();
            if(mStates.newPoll == 1){
                mStates.newPoll = 0;    
                if(mStates.distanceToTravel - mStates.encoderval1 <=0 || mStates.distanceToTravel - mStates.encoderval2 <=0)
                {
                  mStates.current_State = ROVER_HOLD;
                  mStates.distanceTraveled = mStates.distanceTraveled + (mStates.encoderval1 + mStates.encoderval2)/2;
                }
                else
                {
                    mStates.distanceToTravel = mStates.distanceToTravel-(mStates.encoderval1 + mStates.encoderval2)/2;
                }
            }             
            break;
        case ROVER_HOLD:
            setMotor(0,1);
            setMotor(0,0);
            directionForward();
            mStates.counter = 0;
            break;
        default:
            setMotor(0,1);
            setMotor(0,0);
            directionForward();
            break;
    }
                        
    
}
