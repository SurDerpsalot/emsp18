/* 
 * File:   MotorControl.h
 * Author: Brad
 *
 * Created on March 12, 2018, 7:57 PM
 */

typedef enum {ROVER_FORWARD, ROVER_BACKWARD, ROVER_RIGHT, ROVER_LEFT, ROVER_HOLD,
              ROVER_TURN_TEST, ROVER_BACKWARDS_TURN_TEST, ROVER_LENGTH_FINDING_TEST} state;
typedef enum {NORTH, EAST, SOUTH, WEST} orientation;
typedef struct motorStates motorStates;
struct motorStates {
    int current_State;
    int current_Speed_M1;
    int current_Speed_M2;
    float distanceTraveled;
    float encoderval1;
    float encoderval2;
    int current_Orientation;
    float timeToReachObj;
    int distanceToTravel;
    int current_Direction_M1;
    int current_Direction_M2;
    int counter;
    int newPoll;
    int rght;
    int fwd;
};

int ninetyDegreeTurn1 = 560;
int ninetyDegreeTurn2 = 679;
int ninetyDegreeTurn3 = 710;
int forwardValue12Inches = 1830;


motorStates mStates;


void motorState();

void directionForward(){
    PLIB_PORTS_PinClear(0, 0x02, 14);
    PLIB_PORTS_PinClear(0, 0x06, 1);
}
void directionBackward(){
    PLIB_PORTS_PinSet(0, 0x02, 14);
    PLIB_PORTS_PinSet(0, 0x06, 1);
}
void directionRight(){
    PLIB_PORTS_PinSet(0, 0x02, 14);
    PLIB_PORTS_PinClear(0, 0x06, 1);
}
void directionLeft(){
    PLIB_PORTS_PinClear(0, 0x02, 14);
    PLIB_PORTS_PinSet(0, 0x06, 1);
}

void setMotor(int fast, int motor) {
    if(fast <101){
        fast = speedMapping(fast);
    }
    else
    {
        //return error
        fast = 10;
    }
    if(motor == 1){
        DRV_OC1_PulseWidthSet(fast);
    }
    else{
        DRV_OC0_PulseWidthSet(fast);
    }
}

//insert table
int speedMapping(int fast){
    switch(fast){
        case 100:
            return 799;
        case 90:
            return 740;
        case 80:
            return 720;
        case 70:
            return 700;
        case 60:
            return 680;
        case 50:
            return 660;
        case 40:
            return 640;
        case 30:
            return 620;
        case 20:
            return 580;
        case 10:
            return 520;
        case 0:
            return 1;
        default:
            return 500;
    }
}